﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FineUI;
using Demo.BLL;
using Demo.Model;

namespace Demo.Web.JC.Deptment
{
    public partial class listpositionadd1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindEnumrableToDropDownList();  //绑定下拉菜单
        }

        public class CustomClass
        {
            private string _id;

            public string ID
            {
                get { return _id; }
                set { _id = value; }
            }
            private string _name;

            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }

            public CustomClass(string id, string name)
            {
                _id = id;
                _name = name;
            }
        }


        private void BindEnumrableToDropDownList()
        {
            List<CustomClass> myList = new List<CustomClass>();

            Demo.BLL.tb_JC_Department bll = new Demo.BLL.tb_JC_Department();

            //泛型
            List<Demo.Model.tb_JC_Department> model = new List<Demo.Model.tb_JC_Department>();

            model = bll.GetModelList("");

            foreach (Demo.Model.tb_JC_Department temp in model)
            {
                myList.Add(new CustomClass(temp.DepartmentNO, temp.DepartmentName));

            }



            deptno.DataTextField = "Name";
            deptno.DataValueField = "ID";
            deptno.DataSource = myList;
            deptno.DataBind();

        }





        protected void btnSaveRefresh_Click(object sender, EventArgs e)
        {
            // 1. 这里放置保存窗体中数据的逻辑

            Demo.BLL.tb_JC_Position bll = new Demo.BLL.tb_JC_Position();
            Demo.Model.tb_JC_Position model = new Demo.Model.tb_JC_Position();

            model.ID = Guid.NewGuid().ToString();
            model.PositionNO = positionnno.Text.Trim();
            model.PositionName = positionname.Text.Trim();
            model.DepartmentNO = deptno.Text.Trim();


            if (bll.Add(model))
            {
                Alert.ShowInTop("添加成功");
            }
            else
            {
                Alert.ShowInTop("添加失败");
            }

            // 2. 关闭本窗体，然后刷新父窗体
            PageContext.RegisterStartupScript(ActiveWindow.GetHideRefreshReference());
        }
    }
}